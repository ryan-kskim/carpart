"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Created by vega on 2017-05-29.
 */
var ZipCodeValidator_1 = require("./ZipCodeValidator");
var myValidator = new ZipCodeValidator_1.ZipCodeValidator();
var ZipCodeValidator_2 = require("./ZipCodeValidator");
var myValidator2 = new ZipCodeValidator_2.ZipCodeValidator();
var validator = require("./ZipCodeValidator");
var myValidator3 = new validator.ZipCodeValidator();
