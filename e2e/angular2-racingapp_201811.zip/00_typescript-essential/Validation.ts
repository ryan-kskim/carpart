/**
 * Created by vega on 2017-05-29.
 */
export interface StringValidator {
    isAcceptable(s: string): boolean;
}