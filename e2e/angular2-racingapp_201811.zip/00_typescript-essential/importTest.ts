/**
 * Created by vega on 2017-05-29.
 */
import { ZipCodeValidator } from "./ZipCodeValidator";

let myValidator = new ZipCodeValidator();

import { ZipCodeValidator as ZCV } from "./ZipCodeValidator";
let myValidator2 = new ZCV();


import * as validator from "./ZipCodeValidator";
let myValidator3 = new validator.ZipCodeValidator();