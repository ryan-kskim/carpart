/**
 * Created by vega on 2017-05-28.
 */
enum Color {Red = 1, Green, Blue}
let colorName: string = Color[2];

console.log(colorName);

let someValue: any = "this is a string";

//let strLength: number = (<string>someValue).length
let strLength: number = (someValue as string).length
console.log(strLength);