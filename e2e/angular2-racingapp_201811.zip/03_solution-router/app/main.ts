import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {AppComponent} from './app.component';
import {CarPartComponent} from './car-part/car-part.component';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RacingDataService} from './car-part/racing-data.service';
import {HttpModule} from '@angular/http';

import {AboutComponent} from './about.component';
import {AppRoutingModule} from "./app-routing.module";

@NgModule({
    declarations: [
        AppComponent,
        AboutComponent,
        CarPartComponent
    ],
    imports: [ BrowserModule,FormsModule,HttpModule,AppRoutingModule ],
    bootstrap: [ AppComponent ],
    providers: [ RacingDataService ]
})
class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);