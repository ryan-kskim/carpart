import {NgModule} from "@angular/core"
import {RouterModule} from "@angular/router";
import {AboutComponent} from "./about.component";
import {CarPartComponent} from "./car-part/car-part.component";

@NgModule({
    imports:[RouterModule.forRoot([
        { path: '', component: AboutComponent },
        { path: 'carpart', component: CarPartComponent }
    ])],
    exports:[RouterModule]
})
export class AppRoutingModule {
}
