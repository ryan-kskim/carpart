import {Component} from "@angular/core";
import {CarPart} from "./car-part";
import {CARPARTS} from "./mocks";
import { RacingDataService } from './racing-data.service';

@Component({
    selector: 'car-parts',
    templateUrl: 'app/car-part/car-part.component.html',
    styleUrls: ['app/car-part/car-part.component.css']
})
export class CarPartComponent {
    title = 'Ultra Racing';

    carParts: CarPart[];

    constructor(private racingDataService: RacingDataService) { }

    ngOnInit() {
        //let racingDataService = new RacingDataService();
        this.racingDataService.getCarParts().subscribe(carParts => this.carParts = carParts);
    }

    totalCarParts(): number {

        let sum: number = 0;
        if(Array.isArray(this.carParts)) {
            for (let carPart of this.carParts) {
                sum += carPart.inStock;
            }
        }
        return sum;
    }

    upQuantity(carPart) {
        if(carPart.quantity < carPart.inStock) carPart.quantity++;
        console.log("===>" + carPart);
    }

    downQuantity(carPart) {
        if (carPart.quantity != 0) carPart.quantity--;
    }
}
