import {Component} from '@angular/core';
import {FormControl, FormGroup, Validators, FormBuilder, NgForm} from '@angular/forms';
import {ActivatedRoute} from "@angular/router";

@Component({
    selector: 'car-part-form',
    templateUrl: 'app/car-part/car-part-form.component.html',
    styleUrls: ['app/car-part/car-part.component.css']
})
export class CarPartFormComponent {

    carPartForm:FormGroup = new FormGroup({
        id: new FormControl('', Validators.required),
        name: new FormControl('', Validators.required),
        description: new FormControl('', Validators.required),
        price:new FormControl('', Validators.compose([Validators.required,
            Validators.pattern('[0-9]')])),
        quantity:new FormControl('', Validators.required)
    })

    constructor(private route: ActivatedRoute){}

    onSubmit(form: NgForm){
        let formData = form.value as CarPart;

        console.log(form.value);
        console.log('id:' + form.controls['id'].value);
        console.log('name:' + form.controls['name'].value);
        console.log('description:' + form.controls['description'].value);
        console.log('price:' + form.controls['price'].value);
        console.log('quantity:' + form.controls['quantity'].value);
        console.log('Form Valid:' + form.valid);
        console.log('Form Submitted:' + form.submitted);

        //this.route.navigate("/carpart");
    }

    onSubmit_reactive() {
        //FormGroup을 사용했을 때 Form의 값 가져오기
        console.log(this.carPartForm.value);
        console.log('>>id:' + this.carPartForm.controls['id'].value);

    }
}