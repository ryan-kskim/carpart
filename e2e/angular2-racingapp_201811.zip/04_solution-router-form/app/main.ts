import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RacingDataService} from './car-part/racing-data.service';
import {HttpModule} from '@angular/http';
import {AppRoutingModule} from './app.routes';
import {ReactiveFormsModule }   from '@angular/forms';

import {AppComponent} from './app.component';
import {AboutComponent} from './about.component';
import {CarPartComponent} from './car-part/car-part.component';
import {CarPartFormComponent} from './car-part/car-part-form.component';


@NgModule({
    declarations: [
        AppComponent,
        AboutComponent,
        CarPartComponent,
        CarPartFormComponent
    ],
    imports: [ BrowserModule,FormsModule,HttpModule,AppRoutingModule,ReactiveFormsModule ],
    bootstrap: [ AppComponent ],
    providers: [ RacingDataService ]
})
class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);