import { ModuleWithProviders }       from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarPartComponent } from './car-part/car-part.component';
import { AboutComponent } from './about.component';
import { CarPartFormComponent } from './car-part/car-part-form.component';

export const routes: Routes = [
  { path: '', component: AboutComponent },
  { path: 'carpart', component: CarPartComponent },
  { path: 'carpartform', component: CarPartFormComponent }
]

export const AppRoutingModule:ModuleWithProviders = RouterModule.forRoot(routes);