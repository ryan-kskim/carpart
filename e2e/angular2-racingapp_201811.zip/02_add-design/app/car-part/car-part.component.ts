/**
 * Created by vega on 2017-05-26.
 */

import {Component} from "@angular/core";
import {CarPart} from "./car-part";
import {CARPARTS} from "./mocks";

@Component({
    selector:"car-parts",
    templateUrl : "app/car-part/car-part.component.html",
    styleUrls:["app/car-part/car-part.component.css"]
})
export class CarPartComponent {
    carParts:CarPart[];

    ngOnInit(){
        this.carParts = CARPARTS;
    }

    totalCarParts() {
        return this.carParts.reduce((prev,curr) => prev + curr.inStock,0);
    }
}