"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CarPart = (function () {
    function CarPart() {
    }
    return CarPart;
}());
exports.CarPart = CarPart;
//# sourceMappingURL=car-part.js.map