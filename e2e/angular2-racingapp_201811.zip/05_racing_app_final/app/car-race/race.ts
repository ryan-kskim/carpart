/**
 * Created by 206-001 on 2017-05-31.
 */
export class Race {
    id:number;
    name:string;
    date:Date;
    about:string;
    entryFee:number;
    isRacing:boolean;
    image:string;
    imageDescription:string;
}