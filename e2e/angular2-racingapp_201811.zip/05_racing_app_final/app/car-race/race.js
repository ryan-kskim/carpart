"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Created by 206-001 on 2017-05-31.
 */
var Race = (function () {
    function Race() {
    }
    return Race;
}());
exports.Race = Race;
//# sourceMappingURL=race.js.map