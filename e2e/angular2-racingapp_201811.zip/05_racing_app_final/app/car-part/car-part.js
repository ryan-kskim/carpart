"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Created by 206-001 on 2017-05-30.
 */
//Model class
var CarPart = (function () {
    function CarPart() {
    }
    return CarPart;
}());
exports.CarPart = CarPart;
//# sourceMappingURL=car-part.js.map