import {Injectable} from "@angular/core";
import {Http,Response} from "@angular/http";

import {Observable} from "rxjs/Observable";
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/toPromise";

import {CarPart} from "./car-part";

@Injectable()
export class RacingDataService {
    constructor(private http:Http){}

    getCarPartsPromise() {
        return this.http.get('app/car-part/car-parts.json')
            .toPromise()
            .then(res => <CarPart[]> res.json().data)
            .catch(resError => console.log(resError));
    }


    getCarParts() {
        let jsonData = this.http.get('app/car-part/car-parts.json');
        // console.log('------------');
        // console.log(jsonData);
        jsonData.map(res => res.json().data as CarPart[]).subscribe(function(data){
           console.log(data);
        });
        // console.log('------------');

        //local에 있는 json 호출
        // return this.http.get('app/car-part/car-parts.json')
        //        .map(res => <CarPart[]> res.json().data)
        //        .catch(this.handleError);

        return this.http.get('http://localhost:52274/products')
            .map(res => <CarPart[]> res.json().data)
            .catch(this.handleError);

    }//getCarParts()

    private handleError(resError:Response) {
        console.log(resError);
        alert(resError.toString());
        return Observable.throw(resError.json().error);
    }


}
