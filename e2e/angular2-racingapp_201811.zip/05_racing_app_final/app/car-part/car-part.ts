/**
 * Created by 206-001 on 2017-05-30.
 */
//Model class
export class CarPart {
    id:number;
    name:string;
    description:string;
    price:number;
    inStock:number;
    image:string;
    featured:boolean;
    quantity:0;
}
